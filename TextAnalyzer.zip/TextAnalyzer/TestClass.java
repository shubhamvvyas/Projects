import static org.junit.Assert.assertEquals;
import javax.swing.JFrame;
import org.junit.Test;
import junit.framework.Assert;


public class TestClass {

	
	@Test
	public void testWordCount()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
		int a = sfa.wordCount(filePath);
	    Assert.assertEquals(9, a);
	}
	
	@Test
	public void testSentenceCount ()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
	    Assert.assertEquals(5, sfa.sentenceCount (filePath));
	}

	@Test
	public void testParagraphCount()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
	    Assert.assertEquals(1, sfa.paragraphCount(filePath));
	}


	@Test
	public void testCharacterCount ()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
	    Assert.assertEquals(56, sfa.characterCount(filePath));
	}

	@Test
	public void testWhitespaceCount ()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
	    Assert.assertEquals(8, sfa.whitespaceCount());
	}

	@Test
	public void testAvgCharPl()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
	    Assert.assertEquals(11, sfa.avgCharPl());
	}

	@Test
	public void testAvgWordL()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
	  	Assert.assertEquals(6, sfa.avgWordL());
	}  

	@Test
	public void testMostRepeatedWord()
	{
		String filePath = "C:\\Users\\shubhamvvyas\\Desktop\\Sample.txt";
		Stats_File_Analyzer sfa = new Stats_File_Analyzer(filePath);
	    Assert.assertEquals("shubham", sfa.mostRepeatedWord(filePath));
	}
	
	
	
	@Test
	public void testGUIFWB() {
		FirstWindowBuilder fwb = new FirstWindowBuilder();
		assertEquals(JFrame.EXIT_ON_CLOSE, fwb.getDefaultCloseOperation());
	}
	
}
